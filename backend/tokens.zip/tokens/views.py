import json

from django.db import IntegrityError, transaction
from django.db.models import Max
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .models import Token


@csrf_exempt
@require_POST
def create_token(request):

    # Read and validate request data
    try:
        data = json.loads(request.body)

    except json.JSONDecodeError:
        return JsonResponse(
            {"error": "Invalid JSON"},
            status=400
        )

    # Get required values
    name = data.get("name")
    queue_id = data.get("queue_id")

    # Validate name
    if not isinstance(name, str) or not name.strip():
        return JsonResponse(
            {"error": "Name is required"},
            status=400
        )

    # Validate queue_id
    try:
        queue_id = int(queue_id)

        if queue_id <= 0:
            raise ValueError

    except (TypeError, ValueError):
        return JsonResponse(
            {"error": "A valid queue_id is required"},
            status=400
        )

    # Get today's date
    service_date = timezone.localdate()

    # Generate a unique token number
    for attempt in range(5):

        try:
            with transaction.atomic():

                # Find the highest existing token number
                last_token = (
                    Token.objects
                    .filter(
                        queue_id=queue_id,
                        service_date=service_date,
                    )
                    .aggregate(
                        max_number=Max("number")
                    )
                )

                last_number = last_token["max_number"] or 0

                # Generate the next number
                next_number = last_number + 1

                # Create token
                token = Token.objects.create(
                    name=name.strip(),
                    queue_id=queue_id,
                    service_date=service_date,
                    number=next_number,
                )

            # Return success response
            return JsonResponse(
                {
                    "message": "Token created successfully",
                    "token_id": token.id,
                    "name": token.name,
                    "queue_id": token.queue_id,
                    "service_date": str(token.service_date),
                    "number": token.number,
                },
                status=201
            )

        except IntegrityError:

            # Another request may have created the same number.
            # Retry with the latest available number.
            if attempt == 4:
                return JsonResponse(
                    {
                        "error": (
                            "Unable to generate a unique token. "
                            "Please try again."
                        )
                    },
                    status=409
                )

    return JsonResponse(
        {"error": "Token generation failed"},
        status=500
    )