from django.db import models


class Token(models.Model):
    name = models.CharField(max_length=100)

    queue_id = models.PositiveIntegerField(
        null=True,
        blank=True
    )

    service_date = models.DateField()

    number = models.PositiveIntegerField()

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["queue_id", "service_date", "number"],
                name="unique_token_per_queue_date_number"
            )
        ]

        ordering = ["number"]

    def _str_(self):
        return f"{self.name} - Queue {self.queue_id} - Token {self.number}"