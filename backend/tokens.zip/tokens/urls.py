from django.urls import path
from . import views

urlpatterns = [
    path(
        "generate/",
        views.create_token,
        name="create_token",
    ),
]